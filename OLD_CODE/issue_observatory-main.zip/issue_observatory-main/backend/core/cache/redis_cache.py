import logging
from typing import Optional
from backend.core.nlp.cache import get_analysis_cache

logger = logging.getLogger(__name__)

async def close_redis():
    """
    Close the Redis connection. 
    This is what main.py is looking for.
    """
    try:
        cache = await get_analysis_cache()
        await cache.close()
        logger.info("Redis connection closed successfully.")
    except Exception as e:
        logger.error(f"Error closing Redis: {e}")

async def get_redis_cache():
    """Provides the cache instance for FastAPI dependencies."""
    return await get_analysis_cache()
