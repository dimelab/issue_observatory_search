# Issue Observatory (IOS) - Production Guide

The Issue Observatory is a  platform for scraping, analyzing, and visualizing digital discourse. 
It leverages NLP for entity extraction and network science to map relationships between actors and issues.

## Architecture
The application is built with a decoupled architecture to handle long-running scraping and analysis tasks.

### Stack

- **Backend:** FastAPI (Python 3.x)
    
- **Task Queue:** Celery + Redis
    
- **Database:** PostgreSQL + `pgvector` (Semantic Search)
    
- **NLP:** Spacy/Transformers (NER & Analysis)
    
- **Frontend:** FastAPI Templates (Jinja2) + Graphology (Visualizations)
    

### Docker Containerized Services (local on DMLBeast)

| **Service**    | **Container Name**                | **Port**       | **Purpose**                          |
| -------------- | --------------------------------- | -------------- | ------------------------------------ |
| **PostgreSQL** | `issue_observatory_db`            | `5433:5432`    | DB with pgvector support.            |
| **Redis**      | `issue_observatory_redis`         | `6379:6379`    | Broker for Celery & caching.         |
| **Backend**    | `issue_observatory_backend`       | `8080:8000`    | FastAPI Web Server & API.            |
| **Worker**     | `issue_observatory_celery_worker` | does not apply | Scraping, NLP, & Network generation. |
| **Beat**       | `issue_observatory_celery_beat`   | does not apply | Task scheduler for recurring jobs.   |
| **Flower**     | `issue_observatory_flower`        | `5555:5555`    | Real-time Celery monitoring.         |
| **Nginx**      | `issue_observatory_nginx`         | `80:80`        | Reverse proxy                        |

---

## Project structure

Bash

```
.
├── alembic/              # Database migration scripts
├── backend/
│   ├── api/              # API Endpoints (FastAPI Routers)
│   ├── core/             # Business logic (Scrapers, NLP, Search Engines)
│   ├── models/           # SQLAlchemy ORM Models
│   ├── services/         # Orchestration logic (Analysis, Search, Scraping)
│   └── tasks/            # Celery task definitions
├── docker/               # Dockerfiles and SQL init scripts
├── docs/                 # Extensive documentation (60+ guides)
├── frontend/             # Jinja2 templates and assets
├── scripts/              # Utility scripts for maintenance & data fixes
└── tests/                # Integration and Unit tests
```

---

## Maintenance and exec. commands

All commands should be executed from `/var/www/ios_prod` on **DMLBeast**.

### Essential

- **Update prod:**
    
    Bash
    
    ```
    git pull origin main && docker compose -f docker-compose.prod.yml up --build -d
    ```
    
- **Check logs:**
    
    Bash
    
    ```
    docker compose logs -f backend         # Web API
    docker compose logs -f celery_worker   # Background Tasks
    ```
    
- **Db access:**
    
    Bash
    
    ```
    docker exec -it issue_observatory_db psql -U postgres -d issue_observatory
    ```
    

### Backups

Backups will be stored off server. 
Contact hsahmad/jakobbaek for backup.

---

## TS and db migrations

### Applying Database Changes (Alembic)

**1. Run migrations:**

Bash

```
docker exec -it issue_observatory_backend alembic upgrade head
```

**2. Manual fix scripts:**

If migrations fail, use the provided maintenance scripts:

Bash

```
docker exec -it issue_observatory_backend python scripts/add_excluded_domains_column.py
docker exec -it issue_observatory_backend python scripts/fix_analysis_columns.py
```

### Worker volumes

> 
> The Celery Worker requires root volume mapping and the correct `PYTHONPATH` to see the `backend` module. Ensure the `docker-compose` includes:
> 
> YAML
> ```
> volumes:
>   - .:/app
> environment:
>   - PYTHONPATH=/app
> ```

---

## 📑 Documentation Reference

For detailed feature content see the `docs/` folder.
